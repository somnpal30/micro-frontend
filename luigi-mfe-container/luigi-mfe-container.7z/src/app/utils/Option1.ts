export class Option1 extends Option{
   pathValue: string;
}
