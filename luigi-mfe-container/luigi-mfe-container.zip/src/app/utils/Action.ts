export class Action {
  label: string;
  link: string;
  lang: string;
  clickHandler: string;


}
