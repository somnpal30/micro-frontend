import {Action} from "./Action";

export class ContextSwitcher {
  defaultLabel: string;
  parentNodePath: string;
  lazyloadOptions: boolean;
  options: any[];
  actions: Action[];

  constructor() {
    
  }

}

