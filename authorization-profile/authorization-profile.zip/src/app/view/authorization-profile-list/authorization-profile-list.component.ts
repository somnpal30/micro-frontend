import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorization-profile-list',
  templateUrl: './authorization-profile-list.component.html',
  styleUrls: ['./authorization-profile-list.component.css']
})
export class AuthorizationProfileListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
