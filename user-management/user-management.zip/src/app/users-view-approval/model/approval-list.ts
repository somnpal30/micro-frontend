export interface ApprovalList {
  id: string,
  approval_type: string,
  approval_level: string,
  submitted_by: string,
  submitted_on: string
}
